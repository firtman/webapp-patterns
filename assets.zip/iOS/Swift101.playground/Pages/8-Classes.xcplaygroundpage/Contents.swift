/*: * Classes
 Full support for OOP, not very useful on the SwiftUI side
 Classes can be extended
*/
