/*: * Protocols
 Categorization of custom types
 It can define optional or mandatory methods and properties
*/
