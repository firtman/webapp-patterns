/*: * Structs
 Data with methods and rules, no inheritance, protocol-based
 Passed by value (copy) but fast and optimized
 There is a default initializer
*/
