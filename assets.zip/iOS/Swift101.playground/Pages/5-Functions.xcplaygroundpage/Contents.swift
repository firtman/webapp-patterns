/*: * Functions
 A surprise is waiting in this matter with argument labels
*/

func aFunction() {
    print("I'm a function")
}

func aFunctionReturning() -> String {
    return "I'm a function"
}

func aFunctionReturning2() -> String {
    "I'm a function"
}

// Arguments
func sum(a: Int, b: Int) -> Int {
    return a+b
}

// How do you call sum?
